import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:shop_app/constants.dart';
import 'package:shop_app/screens/Welcome/components/background.dart';

class Body extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context)
        .size; // This size provides us total hight and width of our screen
    return Background(
      // child: Stack(
      //   alignment: Alignment.bottomCenter,
      //   fit: StackFit.passthrough,
      //   children: <Widget>[
      //     Positioned(
      //       child: SvgPicture.asset(
      //         "assets/icons/white_background.svg",
      //         width: size.width,
      //       ),
      //     ),
      //     Positioned(
      //       child: SvgPicture.asset("assets/icons/logo_whispers.svg",
      //           height: size.height * 0.25),
      //     ),
      //     Positioned(
      //       child: Text("Easy & Tasty",
      //           style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
      //     ),
      //   ],
      // ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.end,
        children: <Widget>[
          Text(
            "Easy & Tasty",
            style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
          ),
          Text(
            "Find recipes and restaurants that meet your food preferences and food restrictions.",
            textAlign: TextAlign.center,
            style: TextStyle(fontWeight: FontWeight.normal, fontSize: 14),
          ),
          Align(
            alignment: Alignment.center,
            child: SvgPicture.asset("assets/icons/logo_whispers.svg",
                height: size.height * 0.25),
          ),
          Align(
            alignment: Alignment.center,
            child: SvgPicture.asset("assets/icons/white_background.svg",
                width: size.width * 0.6),
          ),
          ElevatedButton(
            child: Text("GET STARTED!"),
            onPressed: () => print("it's pressed"),
            style: ElevatedButton.styleFrom(
              primary: kPrimaryColor,
              onPrimary: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(32.0),
              ),
            ),
          )
        ],
      ),
    );
  }
}
